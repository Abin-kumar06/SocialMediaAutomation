"""
Configuration settings
"""
import os
from pathlib import Path
from dotenv import load_dotenv

# Load from project root .env (same folder as main.py)
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(_PROJECT_ROOT / ".env")


def update_env_token(key: str, value: str) -> bool:
    """
    Update or add a key=value line in the project's .env file.
    Returns True if the file was updated successfully.
    """
    env_path = _PROJECT_ROOT / ".env"
    try:
        lines = []
        if env_path.exists():
            lines = env_path.read_text(encoding="utf-8", errors="replace").splitlines()
        key_prefix = f"{key}="
        new_line = f'{key}="{value}"' if (" " in value or "#" in value or "\n" in value) else f"{key}={value}"
        found = False
        for i, line in enumerate(lines):
            if line.strip().startswith(key_prefix) or (line.strip() and line.split("=", 1)[0].strip() == key):
                lines[i] = new_line
                found = True
                break
        if not found:
            lines.append(new_line)
        env_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        return True
    except Exception:
        return False


class Settings:
    """Application settings"""
    
    # Instagram API
    INSTAGRAM_ACCOUNT_ID = os.getenv("INSTAGRAM_ACCOUNT_ID", "")
    PAGE_ACCESS_TOKEN = os.getenv("PAGE_ACCESS_TOKEN", "")
    GRAPH_API_VERSION = os.getenv("GRAPH_API_VERSION", "v24.0")
    GRAPH_API_BASE = f"https://graph.facebook.com/{GRAPH_API_VERSION}"
    
    # Facebook App Credentials (for token refresh)
    FB_APP_ID = os.getenv("FB_APP_ID", "")
    FB_APP_SECRET = os.getenv("FB_APP_SECRET", "")
    
    # Image Hosting
    IMGBB_API_KEY = os.getenv("IMGBB_API_KEY", "")
    IMGUR_CLIENT_ID = os.getenv("IMGUR_CLIENT_ID", "")
    
    # AI Content Generation
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    AI_MODEL = os.getenv("AI_MODEL", "gemini-1.5-flash")  # Default to flash (faster, cheaper)
    
    # File Upload
    UPLOAD_DIR = Path("./uploads")
    MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", "10"))
    MAX_FILE_SIZE = MAX_FILE_SIZE_MB * 1024 * 1024
    ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png"}
    
    # LinkedIn API (for future posting)
    LINKEDIN_CLIENT_ID = os.getenv("LINKEDIN_CLIENT_ID", "")
    LINKEDIN_CLIENT_SECRET = os.getenv("LINKEDIN_CLIENT_SECRET", "")
    LINKEDIN_ACCESS_TOKEN = os.getenv("LINKEDIN_ACCESS_TOKEN", "")
    LINKEDIN_REDIRECT_URI = os.getenv("LINKEDIN_REDIRECT_URI", "http://localhost:8000/auth/linkedin/callback")
    
    # Server
    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", "8000"))
    
    def __init__(self):
        # Create upload directory
        self.UPLOAD_DIR.mkdir(exist_ok=True)
    
    def get_config_status(self) -> dict:
        """Check configuration status"""
        return {
            "access_token_configured": bool(self.PAGE_ACCESS_TOKEN),
            "instagram_account_configured": bool(self.INSTAGRAM_ACCOUNT_ID),
            "fb_app_credentials_configured": bool(self.FB_APP_ID and self.FB_APP_SECRET),
            "gemini_configured": bool(self.GEMINI_API_KEY),
            "imgbb_configured": bool(self.IMGBB_API_KEY),
            "imgur_configured": bool(self.IMGUR_CLIENT_ID),
            "hosting_available": bool(self.IMGBB_API_KEY or self.IMGUR_CLIENT_ID),
            "linkedin_configured": bool(self.LINKEDIN_CLIENT_ID and self.LINKEDIN_CLIENT_SECRET),
            "linkedin_token_configured": bool(self.LINKEDIN_ACCESS_TOKEN),
        }


settings = Settings()